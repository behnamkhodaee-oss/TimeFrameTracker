plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.timeframetracker"
    compileSdk = 35

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    defaultConfig {
        applicationId = "com.example.timeframetracker"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "2.1"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
}
