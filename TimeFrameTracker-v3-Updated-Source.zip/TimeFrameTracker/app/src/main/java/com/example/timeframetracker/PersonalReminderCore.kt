package com.example.timeframetracker

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject

/** Independent, persistent one-shot reminders with their own IDs and notifications. */
data class PersonalReminder(val id: Long, val triggerAt: Long, val note: String)

object PersonalReminders {
    private const val PREFS = "personal_reminder_prefs"
    private const val REMINDERS = "reminders_json"
    private const val CHANNEL = "personal_reminders"
    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun all(context: Context): List<PersonalReminder> {
        val raw = prefs(context).getString(REMINDERS, "[]") ?: "[]"
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).mapNotNull { i ->
                val o = array.optJSONObject(i) ?: return@mapNotNull null
                val id = o.optLong("id", 0L)
                val at = o.optLong("at", 0L)
                val note = o.optString("note", "").trim()
                if (id > 0L && at > 0L && note.isNotEmpty()) PersonalReminder(id, at, note) else null
            }
        } catch (_: Exception) { emptyList() }
    }

    private fun save(context: Context, reminders: List<PersonalReminder>) {
        val array = JSONArray()
        reminders.forEach { r ->
            array.put(JSONObject().put("id", r.id).put("at", r.triggerAt).put("note", r.note))
        }
        prefs(context).edit().putString(REMINDERS, array.toString()).apply()
    }

    fun add(context: Context, minutes: Long, note: String): Boolean {
        if (minutes < 1 || note.isBlank()) return false
        val now = System.currentTimeMillis()
        val id = (now * 1000L + (System.nanoTime() % 1000L)).coerceAtLeast(1L)
        val reminder = PersonalReminder(id, now + minutes * 60_000L, note.trim())
        save(context, all(context) + reminder)
        schedule(context, reminder)
        return true
    }

    fun remove(context: Context, id: Long) {
        cancelAlarm(context, id)
        save(context, all(context).filterNot { it.id == id })
    }

    private fun pending(context: Context, reminder: PersonalReminder): PendingIntent {
        val intent = Intent(context, PersonalReminderReceiver::class.java)
            .putExtra("reminder_id", reminder.id)
        return PendingIntent.getBroadcast(
            context, reminder.id.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun cancelAlarm(context: Context, id: Long) {
        val intent = Intent(context, PersonalReminderReceiver::class.java).putExtra("reminder_id", id)
        val pi = PendingIntent.getBroadcast(
            context, id.hashCode(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi)
    }

    fun schedule(context: Context, reminder: PersonalReminder) {
        if (reminder.triggerAt <= System.currentTimeMillis()) return // Never replay overdue reminders.
        val manager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(context, reminder)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !manager.canScheduleExactAlarms()) {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reminder.triggerAt, pi)
            } else {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reminder.triggerAt, pi)
            }
        } catch (_: SecurityException) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reminder.triggerAt, pi)
        }
    }

    fun restoreFuture(context: Context) {
        val now = System.currentTimeMillis()
        val current = all(context)
        current.filter { it.triggerAt > now }.forEach { schedule(context, it) }
        // Expired reminders are discarded instead of firing late after reboot.
        save(context, current.filter { it.triggerAt > now })
    }

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL, "یادآورهای شخصی", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "اعلان یادآورهای دارای یادداشت"
                enableVibration(true)
            }
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    fun notify(context: Context, reminder: PersonalReminder) {
        createChannel(context)
        val open = PendingIntent.getActivity(
            context, reminder.id.hashCode(), Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("یادآوری شخصی")
            .setContentText(reminder.note)
            .setStyle(NotificationCompat.BigTextStyle().bigText(reminder.note))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(reminder.id.hashCode(), notification)
    }

    private val defaultGroupTitles = listOf("جفت‌ارزها", "فلزات و کالاها", "ارزهای دیجیتال", "شاخص‌ها و شخصی")
    fun groupTitle(context: Context, group: Int): String =
        prefs(context).getString("group_title_$group", defaultGroupTitles[group.coerceIn(0, 3)]) ?: defaultGroupTitles[group.coerceIn(0, 3)]
    fun saveGroupTitle(context: Context, group: Int, title: String) {
        if (title.isNotBlank()) prefs(context).edit().putString("group_title_$group", title.trim()).apply()
    }

    fun notes(context: Context, group: Int): List<String> {
        val defaults = listOf(
            listOf("EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCAD", "USDCHF", "NZDUSD", "EURJPY", "GBPJPY", "EURGBP"),
            listOf("XAUUSD", "XAGUSD", "نفت WTI", "نفت Brent", "گاز طبیعی", "مس"),
            listOf("BTCUSD", "ETHUSD", "SOLUSD", "BNBUSD", "XRPUSD", "ADAUSD"),
            listOf("US30", "NAS100", "SPX500", "DXY", "بررسی اخبار", "بررسی واچ‌لیست")
        )
        val key = "notes_group_$group"
        val stored = prefs(context).getString(key, null)
        return (stored?.split('\n')?.map { it.trim() }?.filter { it.isNotEmpty() } ?: defaults[group.coerceIn(0, 3)])
    }

    fun saveNotes(context: Context, group: Int, values: List<String>) {
        prefs(context).edit().putString("notes_group_$group", values.map { it.trim() }.filter { it.isNotEmpty() }.distinct().joinToString("\n")).apply()
    }
}

class PersonalReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra("reminder_id", 0L)
        if (id == 0L) return
        val reminder = PersonalReminders.all(context).firstOrNull { it.id == id } ?: return
        if (reminder.triggerAt > System.currentTimeMillis()) {
            PersonalReminders.schedule(context, reminder)
            return
        }
        PersonalReminders.remove(context, id)
        PersonalReminders.notify(context, reminder)
    }
}
