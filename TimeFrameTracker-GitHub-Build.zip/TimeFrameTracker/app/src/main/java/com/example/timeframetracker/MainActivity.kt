package com.example.timeframetracker

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val elapsedViews = mutableMapOf<String, TextView>()
    private val lastViews = mutableMapOf<String, TextView>()
    private val statusViews = mutableMapOf<String, TextView>()
    private val historyViews = mutableMapOf<String, TextView>()
    private lateinit var clockView: TextView
    private lateinit var sleepButton: Button
    private val blue = Color.rgb(31, 105, 210)
    private val dark = Color.rgb(27, 39, 56)
    private val muted = Color.rgb(105, 119, 139)
    private val red = Color.rgb(190, 48, 43)
    private val green = Color.rgb(28, 132, 82)

    private val ticker = object : Runnable {
        override fun run() {
            if (!isFinishing) {
                clockView.text = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                refreshCards()
                handler.postDelayed(this, 1000)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Tracker.createChannel(this)
        buildScreen()
        askForPermissions()
        handler.post(ticker)
    }

    override fun onResume() {
        super.onResume()
        if (::sleepButton.isInitialized) {
            // Restore only still-future reminders after the app is reopened; never replay overdue ones.
            if (!Tracker.sleeping(this)) Tracker.keys.forEach { Tracker.schedule(this, it) }
            refreshCards()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(20))
            setBackgroundColor(Color.rgb(243, 245, 249))
        }
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        content.addView(text("TimeFrame Tracker", 24, dark, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(4)) })
        content.addView(text("ثبت زمان بررسی و یادآوری چهار تایم‌فریم", 13, muted).apply { gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(10)) })
        clockView = text("--:--:--", 28, dark, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(10))
            background = rounded(Color.WHITE, dp(14))
        }
        content.addView(clockView, matchWrap().apply { bottomMargin = dp(12) })

        sleepButton = Button(this).apply {
            textSize = 14f
            isAllCaps = false
            setOnClickListener { toggleSleep() }
        }
        content.addView(sleepButton, matchWrap().apply { bottomMargin = dp(8) })
        content.addView(text("برای اعلان روی صفحه قفل، مجوز اعلان‌ها را بده و نمایش اعلان برنامه را در تنظیمات گوشی روشن نگه دار.", 11, muted).apply {
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(2), dp(4), dp(12))
        })

        Tracker.keys.forEachIndexed { index, key ->
            content.addView(makeCard(key, Tracker.titles[index]), matchWrap().apply { bottomMargin = dp(12) })
        }
        content.addView(Button(this).apply {
            text = "تنظیم مجوز زمان‌بندی دقیق"
            textSize = 12f
            isAllCaps = false
            setOnClickListener { openExactAlarmSettings() }
        }, matchWrap())
        page.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(page)
        refreshCards()
    }

    private fun makeCard(key: String, title: String): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = rounded(Color.WHITE, dp(16))
            elevation = dp(2).toFloat()
        }
        card.addView(text("تایم‌فریم $title", 18, dark, true))
        card.addView(text("زمان گذشته از آخرین ثبت", 11, muted).apply { setPadding(0, dp(8), 0, dp(3)) })
        val elapsed = text("هنوز ثبت نشده", 22, blue, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(8)) }
        elapsedViews[key] = elapsed
        card.addView(elapsed, matchWrap())
        val last = text("آخرین ثبت: —", 12, muted).apply { gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(7)) }
        lastViews[key] = last
        card.addView(last)

        val intervalRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        intervalRow.addView(text("هشدار بعد از (دقیقه):", 12, dark), LinearLayout.LayoutParams(0, dp(48), 1f))
        val input = EditText(this).apply {
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            textSize = 15f
            gravity = Gravity.CENTER
            setText(Tracker.interval(this@MainActivity, key).toString())
            setPadding(dp(8), 0, dp(8), 0)
            background = rounded(Color.rgb(245, 247, 250), dp(8))
        }
        intervalRow.addView(input, LinearLayout.LayoutParams(dp(90), dp(44)))
        card.addView(intervalRow)
        card.addView(Button(this).apply {
            text = "ذخیره فاصله هشدار"
            textSize = 12f
            isAllCaps = false
            setOnClickListener {
                val minutes = input.text.toString().toLongOrNull()
                if (minutes == null || minutes < 1) {
                    Toast.makeText(this@MainActivity, "یک عدد معتبر (حداقل ۱ دقیقه) وارد کن.", Toast.LENGTH_SHORT).show()
                } else {
                    Tracker.setInterval(this@MainActivity, key, minutes)
                    if (Tracker.last(this@MainActivity, key) > 0L && !Tracker.sleeping(this@MainActivity)) {
                        Tracker.markAlerted(this@MainActivity, key) // Changing interval starts a fresh one-shot schedule only when still in the future.
                        val prefs = getSharedPreferences(Tracker.PREFS, MODE_PRIVATE)
                        prefs.edit().putBoolean("alerted_$key", false).apply()
                        Tracker.schedule(this@MainActivity, key)
                    }
                    Toast.makeText(this@MainActivity, "فاصله هشدار ذخیره شد.", Toast.LENGTH_SHORT).show()
                    refreshCards()
                }
            }
        }, matchWrap().apply { topMargin = dp(4) })

        val register = Button(this).apply {
            text = "ثبت زمان بررسی همین لحظه"
            textSize = 14f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(blue, dp(10))
            setOnClickListener {
                Tracker.record(this@MainActivity, key)
                Toast.makeText(this@MainActivity, "زمان تایم‌فریم $title ثبت شد.", Toast.LENGTH_SHORT).show()
                refreshCards()
            }
        }
        card.addView(register, matchWrap().apply { topMargin = dp(8) })
        val status = text("", 12, green, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(5)) }
        statusViews[key] = status
        card.addView(status)
        card.addView(text("آخرین ثبت‌ها", 12, dark, true).apply { setPadding(0, dp(4), 0, dp(4)) })
        val history = text("هنوز ثبتی وجود ندارد.", 11, muted).apply { setPadding(dp(9), dp(7), dp(9), dp(7)); background = rounded(Color.rgb(247, 248, 250), dp(8)) }
        historyViews[key] = history
        val historyScroll = ScrollView(this).apply { isVerticalScrollBarEnabled = true; addView(history) }
        card.addView(historyScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(76)))
        return card
    }

    private fun toggleSleep() {
        val nowSleeping = !Tracker.sleeping(this)
        Tracker.setSleep(this, nowSleeping)
        if (nowSleeping) {
            Tracker.keys.forEach { Tracker.cancel(this, it) }
            Toast.makeText(this, "حالت خواب فعال شد؛ همه هشدارها متوقف شدند.", Toast.LENGTH_LONG).show()
        } else {
            // Deliberately do not re-arm old timestamps. A fresh registration is required.
            Toast.makeText(this, "هشدارها فعال شدند. برای هر تایم‌فریم، پس از بررسی زمان جدید را ثبت کن.", Toast.LENGTH_LONG).show()
        }
        refreshCards()
    }

    private fun refreshCards() {
        if (!::sleepButton.isInitialized) return
        val sleeping = Tracker.sleeping(this)
        sleepButton.text = if (sleeping) "☀️ فعال‌سازی هشدارها" else "🌙 حالت خواب؛ غیرفعال کردن هشدارها"
        sleepButton.setTextColor(Color.WHITE)
        sleepButton.background = rounded(if (sleeping) green else Color.rgb(94, 102, 117), dp(12))
        Tracker.keys.forEachIndexed { index, key ->
            val last = Tracker.last(this, key)
            elapsedViews[key]?.text = if (last == 0L) "هنوز ثبت نشده" else elapsed(System.currentTimeMillis() - last)
            lastViews[key]?.text = if (last == 0L) "آخرین ثبت: —" else "آخرین ثبت: ${Tracker.timeText(last)}  |  ${SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(Date(last))}"
            val alerted = Tracker.alerted(this, key)
            statusViews[key]?.apply {
                text = when {
                    sleeping -> "حالت خواب: اعلان‌ها خاموش‌اند"
                    alerted -> "● هشدار این تایم‌فریم ارسال شده؛ برای شروع دوباره ثبت کن"
                    last > 0L -> "○ در انتظار هشدار بعدی"
                    else -> "○ هنوز زمانی ثبت نشده"
                }
                setTextColor(if (alerted) red else if (sleeping) muted else green)
            }
            val prefs = getSharedPreferences(Tracker.PREFS, MODE_PRIVATE)
            val raw = prefs.getString("history_$key", "") ?: ""
            val lines = raw.split('|').filter { it.isNotBlank() }.take(30)
            historyViews[key]?.text = if (lines.isEmpty()) "هنوز ثبتی وجود ندارد." else lines.joinToString("\n") { stamp ->
                stamp.toLongOrNull()?.let { "• ${Tracker.timeText(it)}  |  ${SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(Date(it))}" } ?: ""
            }
        }
    }

    private fun elapsed(ms: Long): String {
        val total = (ms / 1000).coerceAtLeast(0)
        val days = total / 86400
        val hours = (total % 86400) / 3600
        val mins = (total % 3600) / 60
        val secs = total % 60
        return if (days > 0) "$days روز %02d:%02d:%02d".format(hours, mins, secs) else "%02d:%02d:%02d".format(hours, mins, secs)
    }

    private fun askForPermissions() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 200)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val am = getSystemService(ALARM_SERVICE) as AlarmManager
            if (!am.canScheduleExactAlarms()) {
                Toast.makeText(this, "برای دقیق‌تر بودن هشدارها، مجوز زمان‌بندی دقیق را فعال کن.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
        } else Toast.makeText(this, "در این نسخه اندروید نیازی به این مجوز نیست.", Toast.LENGTH_SHORT).show()
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size.toFloat(); setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable = android.graphics.drawable.GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat()
    }
}
