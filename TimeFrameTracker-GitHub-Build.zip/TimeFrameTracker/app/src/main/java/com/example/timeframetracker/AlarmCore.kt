package com.example.timeframetracker

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Tracker {
    const val PREFS = "tracker_prefs"
    const val SLEEP = "sleep_mode"
    const val CHANNEL = "timeframe_alerts"
    val keys = listOf("1m", "5m", "15m", "1h")
    val titles = listOf("۱ دقیقه", "۵ دقیقه", "۱۵ دقیقه", "۱ ساعت")
    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun last(context: Context, key: String) = prefs(context).getLong("last_$key", 0L)
    fun interval(context: Context, key: String) = prefs(context).getLong("interval_$key", 30L)
    fun alerted(context: Context, key: String) = prefs(context).getBoolean("alerted_$key", false)
    fun sleeping(context: Context) = prefs(context).getBoolean(SLEEP, false)
    fun setSleep(context: Context, value: Boolean) { prefs(context).edit().putBoolean(SLEEP, value).apply() }
    fun setInterval(context: Context, key: String, minutes: Long) { prefs(context).edit().putLong("interval_$key", minutes.coerceAtLeast(1)).apply() }
    fun record(context: Context, key: String, timestamp: Long = System.currentTimeMillis()) {
        val p = prefs(context)
        val old = p.getString("history_$key", "") ?: ""
        val history = (listOf(timestamp.toString()) + old.split('|').filter { it.isNotBlank() }).take(100).joinToString("|")
        p.edit().putLong("last_$key", timestamp).putBoolean("alerted_$key", false).putString("history_$key", history).apply()
        schedule(context, key, timestamp)
    }
    fun markAlerted(context: Context, key: String) { prefs(context).edit().putBoolean("alerted_$key", true).apply() }
    fun cancel(context: Context, key: String) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(context, key))
    }
    private fun pending(context: Context, key: String): PendingIntent {
        val index = keys.indexOf(key).coerceAtLeast(0)
        val intent = Intent(context, AlertReceiver::class.java).putExtra("key", key)
        return PendingIntent.getBroadcast(context, 4100 + index, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
    fun schedule(context: Context, key: String, from: Long = last(context, key)) {
        cancel(context, key)
        if (sleeping(context) || from == 0L || alerted(context, key)) return
        val trigger = from + interval(context, key) * 60_000L
        // Never replay missed alarms after the phone/app has been inactive.
        if (trigger <= System.currentTimeMillis()) return
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending(context, key))
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending(context, key))
            }
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pending(context, key))
        }
    }
    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL, "یادآوری بررسی تایم‌فریم", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "هشدار زمان بررسی نمودارها"
                enableVibration(true)
            }
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    fun showNotification(context: Context, key: String) {
        createChannel(context)
        val index = keys.indexOf(key).coerceAtLeast(0)
        val open = PendingIntent.getActivity(context, 5100 + index, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("زمان بررسی تایم‌فریم رسید")
            .setContentText("زمان بررسی تایم‌فریم ${titles[index]} رسیده است.")
            .setStyle(NotificationCompat.BigTextStyle().bigText("زمان بررسی تایم‌فریم ${titles[index]} رسیده است. پس از بررسی، زمان جدید را در برنامه ثبت کن."))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(6100 + index, notification)
    }
    fun timeText(timestamp: Long): String = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(timestamp))
}

class AlertReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val key = intent.getStringExtra("key") ?: return
        if (key !in Tracker.keys || Tracker.sleeping(context)) return
        // Ignore stale PendingIntents if a newer registration has replaced the old one.
        val due = Tracker.last(context, key) + Tracker.interval(context, key) * 60_000L
        if (due > System.currentTimeMillis() || Tracker.alerted(context, key)) return
        Tracker.markAlerted(context, key)
        Tracker.showNotification(context, key)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED || Tracker.sleeping(context)) return
        // Re-arm only future alerts. Anything that became due while powered off is skipped.
        Tracker.keys.forEach { key -> Tracker.schedule(context, key) }
    }
}
