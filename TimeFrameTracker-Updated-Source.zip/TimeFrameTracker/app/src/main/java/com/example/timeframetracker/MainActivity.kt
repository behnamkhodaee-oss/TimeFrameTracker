package com.example.timeframetracker

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.AlarmManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.AdapterView
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Calendar
import java.util.Locale

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val elapsedViews = mutableMapOf<String, TextView>()
    private val lastViews = mutableMapOf<String, TextView>()
    private val statusViews = mutableMapOf<String, TextView>()
    private val historyViews = mutableMapOf<String, TextView>()
    private val countViews = mutableMapOf<String, TextView>()
    private val reminderViews = mutableMapOf<Long, TextView>()
    private lateinit var reminderMinutesInput: EditText
    private lateinit var reminderNoteInput: EditText
    private lateinit var remindersContainer: LinearLayout
    private lateinit var clockView: TextView
    private lateinit var sleepButton: Button
    private val blue = Color.rgb(31, 105, 210)
    private val dark = Color.rgb(27, 39, 56)
    private val muted = Color.rgb(105, 119, 139)
    private val red = Color.rgb(190, 48, 43)
    private val green = Color.rgb(28, 132, 82)

    private val ticker = object : Runnable {
        override fun run() {
            if (!isFinishing) {
                clockView.text = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                refreshCards()
                handler.postDelayed(this, 1000)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Tracker.createChannel(this)
        PersonalReminders.createChannel(this)
        buildScreen()
        askForPermissions()
        handler.post(ticker)
    }

    override fun onResume() {
        super.onResume()
        if (::sleepButton.isInitialized) {
            // Restore only still-future reminders after the app is reopened; never replay overdue ones.
            if (!Tracker.sleeping(this)) Tracker.keys.forEach { Tracker.schedule(this, it) }
            PersonalReminders.restoreFuture(this)
            refreshCards()
            refreshPersonalReminders()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(20))
            setBackgroundColor(Color.rgb(243, 245, 249))
        }
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        content.addView(text("TimeFrame Tracker", 24, dark, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(4)) })
        content.addView(text("ثبت زمان بررسی و یادآوری چهار تایم‌فریم", 13, muted).apply { gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(10)) })
        clockView = text("--:--:--", 28, dark, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(10))
            background = rounded(Color.WHITE, dp(14))
        }
        content.addView(clockView, matchWrap().apply { bottomMargin = dp(12) })

        sleepButton = Button(this).apply {
            textSize = 14f
            isAllCaps = false
            setOnClickListener { toggleSleep() }
        }
        content.addView(sleepButton, matchWrap().apply { bottomMargin = dp(8) })
        content.addView(text("برای اعلان روی صفحه قفل، مجوز اعلان‌ها را بده و نمایش اعلان برنامه را در تنظیمات گوشی روشن نگه دار.", 11, muted).apply {
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(2), dp(4), dp(12))
        })
        content.addView(Button(this).apply {
            text = "ریست همه ثبت‌ها"
            textSize = 12f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(red, dp(10))
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("پاک کردن همه ثبت‌ها؟")
                    .setMessage("تمام تاریخچه و آمار ثبت تایم‌فریم‌ها پاک می‌شود و شمارش از صفر شروع خواهد شد. یادآورها و تنظیمات هشدار تغییر نمی‌کنند.")
                    .setNegativeButton("انصراف", null)
                    .setPositiveButton("پاک کن") { _, _ ->
                        Tracker.clearRecords(this@MainActivity)
                        refreshCards()
                        Toast.makeText(this@MainActivity, "همه ثبت‌ها پاک شدند.", Toast.LENGTH_SHORT).show()
                    }.show()
            }
        }, matchWrap().apply { bottomMargin = dp(12) })

        Tracker.keys.forEachIndexed { index, key ->
            content.addView(makeCard(key, Tracker.titles[index]), matchWrap().apply { bottomMargin = dp(12) })
        }
        buildPersonalReminderSection(content)
        content.addView(Button(this).apply {
            text = "تنظیم مجوز زمان‌بندی دقیق"
            textSize = 12f
            isAllCaps = false
            setOnClickListener { openExactAlarmSettings() }
        }, matchWrap())
        page.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(page)
        refreshCards()
    }

    private fun makeCard(key: String, title: String): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = rounded(Color.WHITE, dp(16))
            elevation = dp(2).toFloat()
        }
        card.addView(text("تایم‌فریم $title", 18, dark, true))
        card.addView(text("زمان گذشته از آخرین ثبت", 11, muted).apply { setPadding(0, dp(8), 0, dp(3)) })
        val elapsed = text("هنوز ثبت نشده", 22, blue, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(8)) }
        elapsedViews[key] = elapsed
        card.addView(elapsed, matchWrap())
        val last = text("آخرین ثبت: —", 12, muted).apply { gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(7)) }
        lastViews[key] = last
        card.addView(last)

        val intervalRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        intervalRow.addView(text("هشدار بعد از (دقیقه):", 12, dark), LinearLayout.LayoutParams(0, dp(48), 1f))
        val input = EditText(this).apply {
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            textSize = 15f
            gravity = Gravity.CENTER
            setText(Tracker.interval(this@MainActivity, key).toString())
            setPadding(dp(8), 0, dp(8), 0)
            background = rounded(Color.rgb(245, 247, 250), dp(8))
        }
        intervalRow.addView(input, LinearLayout.LayoutParams(dp(90), dp(44)))
        card.addView(intervalRow)
        card.addView(Button(this).apply {
            text = "ذخیره فاصله هشدار"
            textSize = 12f
            isAllCaps = false
            setOnClickListener {
                val minutes = input.text.toString().toLongOrNull()
                if (minutes == null || minutes < 1) {
                    Toast.makeText(this@MainActivity, "یک عدد معتبر (حداقل ۱ دقیقه) وارد کن.", Toast.LENGTH_SHORT).show()
                } else {
                    Tracker.setInterval(this@MainActivity, key, minutes)
                    if (Tracker.last(this@MainActivity, key) > 0L && !Tracker.sleeping(this@MainActivity)) {
                        Tracker.markAlerted(this@MainActivity, key) // Changing interval starts a fresh one-shot schedule only when still in the future.
                        val prefs = getSharedPreferences(Tracker.PREFS, MODE_PRIVATE)
                        prefs.edit().putBoolean("alerted_$key", false).apply()
                        Tracker.schedule(this@MainActivity, key)
                    }
                    Toast.makeText(this@MainActivity, "فاصله هشدار ذخیره شد.", Toast.LENGTH_SHORT).show()
                    refreshCards()
                }
            }
        }, matchWrap().apply { topMargin = dp(4) })

        val register = Button(this).apply {
            text = "ثبت زمان بررسی همین لحظه"
            textSize = 14f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(blue, dp(10))
            setOnClickListener {
                Tracker.record(this@MainActivity, key)
                Toast.makeText(this@MainActivity, "زمان تایم‌فریم $title ثبت شد.", Toast.LENGTH_SHORT).show()
                refreshCards()
            }
        }
        card.addView(register, matchWrap().apply { topMargin = dp(8) })
        val status = text("", 12, green, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(5)) }
        statusViews[key] = status
        card.addView(status)
        val count = text("کل ثبت‌ها: ۰  |  اولین ثبت: —", 11, blue, true).apply { setPadding(0, dp(7), 0, dp(3)) }
        countViews[key] = count
        card.addView(count)
        card.addView(text("آخرین ثبت‌ها", 12, dark, true).apply { setPadding(0, dp(4), 0, dp(4)) })
        val history = text("هنوز ثبتی وجود ندارد.", 11, muted).apply { setPadding(dp(9), dp(7), dp(9), dp(7)); background = rounded(Color.rgb(247, 248, 250), dp(8)) }
        historyViews[key] = history
        val historyScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = true
            isFillViewport = false
            addView(history)
            // Keep vertical gestures inside this history list instead of letting the page scroll take over.
            setOnTouchListener { view, event ->
                when (event.actionMasked) {
                    android.view.MotionEvent.ACTION_DOWN -> view.parent.requestDisallowInterceptTouchEvent(true)
                    android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL ->
                        view.parent.requestDisallowInterceptTouchEvent(false)
                }
                false
            }
        }
        card.addView(historyScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(150)))
        return card
    }

    private fun toggleSleep() {
        val nowSleeping = !Tracker.sleeping(this)
        Tracker.setSleep(this, nowSleeping)
        if (nowSleeping) {
            Tracker.keys.forEach { Tracker.cancel(this, it) }
            Toast.makeText(this, "حالت خواب فعال شد؛ همه هشدارها متوقف شدند.", Toast.LENGTH_LONG).show()
        } else {
            // Deliberately do not re-arm old timestamps. A fresh registration is required.
            Toast.makeText(this, "هشدارها فعال شدند. برای هر تایم‌فریم، پس از بررسی زمان جدید را ثبت کن.", Toast.LENGTH_LONG).show()
        }
        refreshCards()
    }

    private fun refreshCards() {
        if (!::sleepButton.isInitialized) return
        val sleeping = Tracker.sleeping(this)
        sleepButton.text = if (sleeping) "☀️ فعال‌سازی هشدارها" else "🌙 حالت خواب؛ غیرفعال کردن هشدارها"
        sleepButton.setTextColor(Color.WHITE)
        sleepButton.background = rounded(if (sleeping) green else Color.rgb(94, 102, 117), dp(12))
        Tracker.keys.forEachIndexed { index, key ->
            val last = Tracker.last(this, key)
            elapsedViews[key]?.text = if (last == 0L) "هنوز ثبت نشده" else elapsed(System.currentTimeMillis() - last)
            lastViews[key]?.text = if (last == 0L) "آخرین ثبت: —" else "آخرین ثبت: ${Tracker.timeText(last)}  |  ${SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(Date(last))}"
            val alerted = Tracker.alerted(this, key)
            statusViews[key]?.apply {
                text = when {
                    sleeping -> "حالت خواب: اعلان‌ها خاموش‌اند"
                    alerted -> "● هشدار این تایم‌فریم ارسال شده؛ برای شروع دوباره ثبت کن"
                    last > 0L -> "○ در انتظار هشدار بعدی"
                    else -> "○ هنوز زمانی ثبت نشده"
                }
                setTextColor(if (alerted) red else if (sleeping) muted else green)
            }
            val prefs = getSharedPreferences(Tracker.PREFS, MODE_PRIVATE)
            val raw = prefs.getString("history_$key", "") ?: ""
            val allLines = raw.split('|').filter { it.isNotBlank() }
            val timestamps = allLines.mapNotNull { it.toLongOrNull() }
            val total = prefs.getInt("count_$key", allLines.size)
            var first = prefs.getLong("first_$key", 0L)
            if (first == 0L && timestamps.isNotEmpty()) {
                first = timestamps.minOrNull() ?: 0L
                if (first > 0L) prefs.edit().putLong("first_$key", first).apply()
            }
            val firstText = if (first > 0L) SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(Date(first)) else "—"
            val now = Calendar.getInstance()
            val dayStart = (now.clone() as Calendar).apply {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            val weekStart = (now.clone() as Calendar).apply {
                firstDayOfWeek = Calendar.getInstance().firstDayOfWeek
                set(Calendar.DAY_OF_WEEK, firstDayOfWeek)
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            val monthStart = (now.clone() as Calendar).apply {
                set(Calendar.DAY_OF_MONTH, 1)
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            val daily = timestamps.count { it >= dayStart }
            val weekly = timestamps.count { it >= weekStart }
            val monthly = timestamps.count { it >= monthStart }
            countViews[key]?.text = "کل ثبت‌ها: $total  |  اولین ثبت: $firstText\nثبت روزانه: $daily  |  ثبت هفتگی: $weekly  |  ثبت ماهانه: $monthly"
            val lines = timestamps.take(100)
            historyViews[key]?.text = if (lines.isEmpty()) "هنوز ثبتی وجود ندارد." else lines.joinToString("\n") { stamp ->
                "• ${Tracker.timeText(stamp)}  |  ${SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(Date(stamp))}"
            }
        }
        updateReminderCountdowns()
    }

    private fun buildPersonalReminderSection(content: LinearLayout) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(Color.WHITE, dp(16))
            elevation = dp(2).toFloat()
        }
        card.addView(text("یادآورهای شخصی", 19, dark, true))
        card.addView(text("چند یادآور مستقل بساز؛ هرکدام اعلان و یادداشت جداگانه دارند.", 11, muted).apply { setPadding(0, dp(4), 0, dp(10)) })

        card.addView(text("چند دقیقه دیگر؟", 12, dark, true))
        reminderMinutesInput = EditText(this).apply {
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            textSize = 15f
            hint = "مثلاً ۲۰"
            setText("20")
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(245, 247, 250), dp(8))
            setPadding(dp(10), 0, dp(10), 0)
        }
        card.addView(reminderMinutesInput, matchWrap().apply { topMargin = dp(4); bottomMargin = dp(6) })

        card.addView(text("زمان‌های پرتکرار", 12, dark, true).apply { setPadding(0, dp(2), 0, dp(2)) })
        val commonMinutes = listOf(1L, 2L, 5L, 10L, 15L, 20L, 30L, 45L, 60L, 90L, 120L, 180L, 240L, 360L, 720L, 1440L)
        val timeSpinner = Spinner(this)
        val timeLabels = listOf("انتخاب زمان آماده…") + commonMinutes.map { minutes ->
            when {
                minutes < 60L -> "$minutes دقیقه"
                minutes % 60L == 0L && minutes < 1440L -> "${minutes / 60L} ساعت"
                minutes == 1440L -> "۱ روز"
                else -> "$minutes دقیقه"
            }
        }
        timeSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, timeLabels).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        var ignoreTimeInitialSelection = true
        timeSpinner.post { ignoreTimeInitialSelection = false }
        timeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (!ignoreTimeInitialSelection && position in 1..commonMinutes.size) {
                    reminderMinutesInput.setText(commonMinutes[position - 1].toString())
                }
            }
        }
        card.addView(timeSpinner, matchWrap().apply { bottomMargin = dp(10) })

        card.addView(text("یادداشت اعلان", 12, dark, true))
        reminderNoteInput = EditText(this).apply {
            setSingleLine(true)
            textSize = 15f
            hint = "مثلاً EURUSD؛ بررسی محدوده ورود"
            background = rounded(Color.rgb(245, 247, 250), dp(8))
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        card.addView(reminderNoteInput, matchWrap().apply { topMargin = dp(4); bottomMargin = dp(10) })

        card.addView(text("یادداشت‌های آماده (پنج فهرست کشویی)", 13, dark, true).apply { setPadding(0, dp(4), 0, dp(6)) })
        for (group in 0..4) {
            val groupTitle = PersonalReminders.groupTitle(this, group)
            card.addView(text(groupTitle, 12, dark, true).apply { setPadding(0, dp(5), 0, 0) })
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val spinner = Spinner(this)
            val values = PersonalReminders.notes(this, group)
            val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, values).also {
                it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            spinner.adapter = adapter
            spinner.prompt = groupTitle
            var ignoreInitialSelection = true
            spinner.post { ignoreInitialSelection = false }
            spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    if (!ignoreInitialSelection && position in values.indices) reminderNoteInput.setText(values[position])
                }
            }
            row.addView(spinner, LinearLayout.LayoutParams(0, dp(48), 1f))
            row.addView(Button(this).apply {
                text = "ویرایش"
                textSize = 11f
                isAllCaps = false
                setOnClickListener { editNoteList(group, groupTitle) }
            }, LinearLayout.LayoutParams(dp(82), dp(44)))
            card.addView(row)
        }

        card.addView(Button(this).apply {
            text = "＋ ثبت یادآور جدید"
            textSize = 14f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(blue, dp(10))
            setOnClickListener {
                val minutes = reminderMinutesInput.text.toString().toLongOrNull()
                val note = reminderNoteInput.text.toString().trim()
                if (minutes == null || minutes < 1 || minutes > 10080) {
                    Toast.makeText(this@MainActivity, "زمان را بین ۱ دقیقه تا ۷ روز وارد کن.", Toast.LENGTH_SHORT).show()
                } else if (note.isBlank()) {
                    Toast.makeText(this@MainActivity, "برای یادآور یک یادداشت بنویس یا از فهرست انتخاب کن.", Toast.LENGTH_SHORT).show()
                } else if (PersonalReminders.add(this@MainActivity, minutes, note)) {
                    Toast.makeText(this@MainActivity, "یادآور ثبت شد.", Toast.LENGTH_SHORT).show()
                    reminderNoteInput.text.clear()
                    refreshPersonalReminders()
                }
            }
        }, matchWrap().apply { topMargin = dp(10) })

        card.addView(text("یادآورهای فعال", 14, dark, true).apply { setPadding(0, dp(14), 0, dp(6)) })
        remindersContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        card.addView(remindersContainer, matchWrap())
        content.addView(card, matchWrap().apply { bottomMargin = dp(14) })
        refreshPersonalReminders()
    }

    private fun editNoteList(group: Int, title: String) {
        val dialogContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val titleInput = EditText(this).apply {
            setText(title)
            hint = "نام فهرست"
            setSingleLine(true)
        }
        val editor = EditText(this).apply {
            setText(PersonalReminders.notes(this@MainActivity, group).joinToString("\n"))
            hint = "هر یادداشت را در یک خط بنویس"
            minLines = 6
            gravity = Gravity.TOP or Gravity.START
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        dialogContent.addView(text("عنوان فهرست", 12, dark, true))
        dialogContent.addView(titleInput, matchWrap())
        dialogContent.addView(text("یادداشت‌ها (هر مورد در یک خط)", 12, dark, true).apply { setPadding(0, dp(10), 0, 0) })
        dialogContent.addView(editor, matchWrap())
        AlertDialog.Builder(this)
            .setTitle("مدیریت فهرست")
            .setView(dialogContent)
            .setNegativeButton("انصراف", null)
            .setPositiveButton("ذخیره") { _, _ ->
                PersonalReminders.saveGroupTitle(this, group, titleInput.text.toString())
                PersonalReminders.saveNotes(this, group, editor.text.toString().split('\n'))
                Toast.makeText(this, "فهرست ذخیره شد.", Toast.LENGTH_SHORT).show()
                buildScreen()
            }.show()
    }

    private fun refreshPersonalReminders() {
        if (!::remindersContainer.isInitialized) return
        remindersContainer.removeAllViews()
        reminderViews.clear()
        val reminders = PersonalReminders.all(this).sortedBy { it.triggerAt }
        if (reminders.isEmpty()) {
            remindersContainer.addView(text("در حال حاضر یادآور فعالی نداری.", 11, muted).apply { setPadding(0, dp(4), 0, dp(4)) })
            return
        }
        reminders.forEach { reminder ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(5), dp(4), dp(5))
                background = rounded(Color.rgb(246, 248, 251), dp(9))
            }
            val remaining = (reminder.triggerAt - System.currentTimeMillis()).coerceAtLeast(0L) / 1000L
            val time = if (remaining >= 3600) "%02d:%02d:%02d".format(remaining / 3600, (remaining % 3600) / 60, remaining % 60)
                       else "%02d:%02d".format(remaining / 60, remaining % 60)
            val label = text("${reminder.note}\nباقی‌مانده: $time", 12, dark, true)
            reminderViews[reminder.id] = label
            row.addView(label, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Button(this).apply {
                text = "لغو"
                textSize = 10f
                isAllCaps = false
                setOnClickListener {
                    PersonalReminders.remove(this@MainActivity, reminder.id)
                    refreshPersonalReminders()
                }
            }, LinearLayout.LayoutParams(dp(68), dp(40)))
            remindersContainer.addView(row, matchWrap().apply { bottomMargin = dp(5) })
        }
    }

    private fun updateReminderCountdowns() {
        if (reminderViews.isEmpty()) return
        val now = System.currentTimeMillis()
        PersonalReminders.all(this).forEach { reminder ->
            val remaining = (reminder.triggerAt - now).coerceAtLeast(0L) / 1000L
            val time = if (remaining >= 3600) "%02d:%02d:%02d".format(remaining / 3600, (remaining % 3600) / 60, remaining % 60)
                       else "%02d:%02d".format(remaining / 60, remaining % 60)
            reminderViews[reminder.id]?.text = "${reminder.note}\nباقی‌مانده: $time"
        }
    }

    private fun elapsed(ms: Long): String {
        val total = (ms / 1000).coerceAtLeast(0)
        val days = total / 86400
        val hours = (total % 86400) / 3600
        val mins = (total % 3600) / 60
        val secs = total % 60
        return if (days > 0) "$days روز %02d:%02d:%02d".format(hours, mins, secs) else "%02d:%02d:%02d".format(hours, mins, secs)
    }

    private fun askForPermissions() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 200)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val am = getSystemService(ALARM_SERVICE) as AlarmManager
            if (!am.canScheduleExactAlarms()) {
                Toast.makeText(this, "برای دقیق‌تر بودن هشدارها، مجوز زمان‌بندی دقیق را فعال کن.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
        } else Toast.makeText(this, "در این نسخه اندروید نیازی به این مجوز نیست.", Toast.LENGTH_SHORT).show()
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size.toFloat(); setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable = android.graphics.drawable.GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat()
    }
}
